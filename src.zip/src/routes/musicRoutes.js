const express = require("express");
const router  = express.Router();
const musicController = require("../controllers/musicController");
const { authMiddleware } = require("../middleware/authMiddleware");

router.get("/songs",              musicController.getAllSongs);
router.get("/songs/:id",          musicController.getSongById);
router.get("/stream/:id",         musicController.streamAudio);
router.post("/record-play/:id",   authMiddleware, musicController.recordPlay);

module.exports = router;
