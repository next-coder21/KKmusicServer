const express = require("express");
const multer  = require("multer");
const authController = require("../controllers/authController");
const userController = require("../controllers/userController");
const musicController = require("../controllers/musicController");
const { authMiddleware } = require("../middleware/authMiddleware");

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

// ─── Public auth ──────────────────────────────────────────────────────────────
router.post("/register",         authController.register);
router.post("/verify",           authController.verifyEmail);
router.post("/resend-otp",       authController.resendOtp);       // ← ADDED
router.post("/login",            authController.login);
router.post("/forgot-password",  authController.forgotPassword);
router.post("/reset-password",   authController.resetPassword);
router.post("/logout",           authController.logout);
router.get ("/check-auth",       authMiddleware, authController.checkAuth);

// ─── Account management (protected) ──────────────────────────────────────────
router.post(
  "/update-account",
  authMiddleware,
  upload.single("image"),
  authController.updateAccount
);

// ─── User data endpoints (protected) ─────────────────────────────────────────
router.get   ("/stats",                    authMiddleware, userController.getStats);
router.get   ("/play-history",             authMiddleware, userController.getPlayHistory);
router.delete("/play-history",             authMiddleware, userController.clearPlayHistory);
router.get   ("/search",                   authMiddleware, userController.search);
router.get   ("/playlists",                authMiddleware, userController.getPlaylists);
router.get   ("/sessions",                 authMiddleware, userController.getSessions);
router.get   ("/notifications",            authMiddleware, userController.getNotifications);
router.patch ("/notifications/:id/read",   authMiddleware, userController.markNotificationRead);
router.patch ("/notifications/read-all",   authMiddleware, userController.markAllNotificationsRead);

// ─── Song interactions (protected) ───────────────────────────────────────────
router.post("/songs/:id/rate",        authMiddleware, userController.rateSong);
router.post("/music/record-play/:id", authMiddleware, musicController.recordPlay); // ← ADDED

module.exports = router;
