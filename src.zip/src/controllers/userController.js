const pool = require('../models/User');

// ─── Helper: get email from request (JWT has { id, email, name }) ─────────────
const getEmail = (req) => req.user?.email;
const getId    = (req) => req.user?.id;

// ─── Stats ────────────────────────────────────────────────────────────────────
exports.getStats = async (req, res) => {
  try {
    const email = getEmail(req);
    if (!email) return res.status(401).json({ error: "Unauthorized" });

    const [listens, playlists, time] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM play_history WHERE user_email = $1', [email]),
      pool.query('SELECT COUNT(*) FROM playlists WHERE user_email = $1', [email]).catch(() => ({ rows: [{ count: 0 }] })),
      pool.query(
        `SELECT COALESCE(SUM(s.duration_seconds), 0) AS total_seconds
         FROM play_history ph
         JOIN songs s ON ph.song_id = s.id
         WHERE ph.user_email = $1`,
        [email]
      ),
    ]);

    res.json({
      total_listens:      parseInt(listens.rows[0].count)  || 0,
      playlists_count:    parseInt(playlists.rows[0].count) || 0,
      listening_time_hrs: Math.round(parseInt(time.rows[0].total_seconds) / 3600) || 0,
    });
  } catch (error) {
    console.error("Stats Error:", error);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
};

// ─── Play History ─────────────────────────────────────────────────────────────
exports.getPlayHistory = async (req, res) => {
  try {
    const email = getEmail(req);
    if (!email) return res.status(401).json({ error: "Unauthorized" });

    const history = await pool.query(
      `SELECT s.id, s.title, a.name AS artist_name, s.cover_url, s.duration_seconds, ph.played_at
       FROM play_history ph
       JOIN songs s ON ph.song_id = s.id
       LEFT JOIN artists a ON s.artist_id = a.id
       WHERE ph.user_email = $1
       ORDER BY ph.played_at DESC
       LIMIT 20`,
      [email]
    );

    res.json(history.rows);
  } catch (error) {
    console.error("Play history error:", error);
    res.status(500).json({ error: "Failed to fetch history" });
  }
};

// ─── Clear Play History ───────────────────────────────────────────────────────
exports.clearPlayHistory = async (req, res) => {
  try {
    const email = getEmail(req);
    if (!email) return res.status(401).json({ error: "Unauthorized" });
    await pool.query('DELETE FROM play_history WHERE user_email = $1', [email]);
    res.json({ message: "Play history cleared" });
  } catch (error) {
    res.status(500).json({ error: "Failed to clear play history" });
  }
};

// ─── Search ───────────────────────────────────────────────────────────────────
exports.search = async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 1) return res.json({ songs: [], artists: [], albums: [] });

    const pattern = `%${q.trim()}%`;

    const [songs, artists, albums] = await Promise.all([
      pool.query(
        `SELECT s.id, s.title, s.cover_url, s.duration_seconds, s.play_count,
                a.name AS artist_name, al.title AS album_title
         FROM songs s
         LEFT JOIN artists a  ON s.artist_id = a.id
         LEFT JOIN albums  al ON s.album_id  = al.id
         WHERE s.title ILIKE $1 OR a.name ILIKE $1
         ORDER BY s.play_count DESC NULLS LAST
         LIMIT 20`,
        [pattern]
      ),
      pool.query(
        `SELECT id, name, image_url,
                (SELECT COUNT(*) FROM songs WHERE artist_id = artists.id) AS song_count
         FROM artists WHERE name ILIKE $1 LIMIT 8`,
        [pattern]
      ),
      pool.query(
        `SELECT al.id, al.title, al.cover_url, a.name AS artist_name
         FROM albums al LEFT JOIN artists a ON al.artist_id = a.id
         WHERE al.title ILIKE $1 LIMIT 8`,
        [pattern]
      ),
    ]);

    res.json({ songs: songs.rows, artists: artists.rows, albums: albums.rows });
  } catch (error) {
    console.error("Search error:", error);
    res.status(500).json({ error: "Search failed" });
  }
};

// ─── Playlists ────────────────────────────────────────────────────────────────
exports.getPlaylists = async (req, res) => {
  try {
    const email = getEmail(req);
    if (!email) return res.status(401).json({ error: "Unauthorized" });

    const playlists = await pool.query(
      `SELECT p.id, p.name, p.is_public AS "isShared",
              COALESCE(COUNT(ps.song_id), 0) AS "songCount"
       FROM playlists p
       LEFT JOIN playlist_songs ps ON p.id = ps.playlist_id
       WHERE p.user_email = $1
       GROUP BY p.id
       ORDER BY p.created_at DESC`,
      [email]
    ).catch(() => ({ rows: [] }));

    res.json(playlists.rows);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch playlists" });
  }
};

// ─── Sessions (mock) ──────────────────────────────────────────────────────────
exports.getSessions = async (req, res) => {
  try {
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
    res.json([
      { id: 1, device: "Current Browser", ip, lastActive: "Active now", isCurrent: true },
    ]);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch sessions" });
  }
};

// ─── Notifications ────────────────────────────────────────────────────────────
exports.getNotifications = async (req, res) => {
  try {
    const email = getEmail(req);
    if (!email) return res.status(401).json({ error: "Unauthorized" });

    const notifs = await pool.query(
      `SELECT * FROM notifications WHERE user_email = $1 ORDER BY created_at DESC LIMIT 30`,
      [email]
    ).catch(() => ({ rows: [] }));

    res.json(notifs.rows);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch notifications" });
  }
};

// ─── Notifications — mark read ────────────────────────────────────────────────
exports.markNotificationRead = async (req, res) => {
  try {
    const email = getEmail(req);
    const { id } = req.params;
    await pool.query(
      'UPDATE notifications SET is_read = TRUE WHERE id = $1 AND user_email = $2',
      [id, email]
    );
    res.json({ message: "Marked as read" });
  } catch (error) {
    res.status(500).json({ error: "Failed to mark as read" });
  }
};

exports.markAllNotificationsRead = async (req, res) => {
  try {
    const email = getEmail(req);
    await pool.query('UPDATE notifications SET is_read = TRUE WHERE user_email = $1', [email]);
    res.json({ message: "All notifications marked as read" });
  } catch (error) {
    res.status(500).json({ error: "Failed to mark all as read" });
  }
};

// ─── Rate Song ────────────────────────────────────────────────────────────────
exports.rateSong = async (req, res) => {
  try {
    const email = getEmail(req);
    if (!email) return res.status(401).json({ error: "Unauthorized" });

    const { id: songId } = req.params;
    const { rating } = req.body; // 1 or -1 or null

    if (rating === null || rating === undefined) {
      await pool.query(
        'DELETE FROM song_ratings WHERE user_email = $1 AND song_id = $2',
        [email, songId]
      ).catch(() => {});
    } else {
      await pool.query(
        `INSERT INTO song_ratings (user_email, song_id, rating) VALUES ($1, $2, $3)
         ON CONFLICT (user_email, song_id) DO UPDATE SET rating = $3`,
        [email, songId, rating]
      ).catch(() => {});
    }

    res.json({ message: "Rating saved" });
  } catch (error) {
    console.error("Rate song error:", error);
    res.status(500).json({ error: "Failed to rate song" });
  }
};
