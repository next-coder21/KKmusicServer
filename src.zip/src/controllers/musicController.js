const pool  = require("../config/db");
const axios = require("axios");

// ─── Helpers ──────────────────────────────────────────────────────────────────
function extractDriveId(url) {
  const patterns = [
    /\/d\/([a-zA-Z0-9_-]{10,})/,
    /[?&]id=([a-zA-Z0-9_-]{10,})/,
  ];
  for (const re of patterns) {
    const m = url.match(re);
    if (m) return m[1];
  }
  return null;
}

async function resolveDriveUrl(fileId) {
  const base = `https://drive.google.com/uc?export=download&id=${fileId}`;
  try {
    const check = await axios.get(base, {
      maxRedirects: 5,
      validateStatus: () => true,
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    if (typeof check.data === "string" && check.data.includes("confirm=")) {
      const token = (check.data.match(/confirm=([0-9A-Za-z_-]+)/) || [])[1];
      if (token) return `https://drive.google.com/uc?export=download&confirm=${token}&id=${fileId}`;
    }
  } catch {}
  return base;
}

// ─── GET all songs ────────────────────────────────────────────────────────────
exports.getAllSongs = async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        s.id, s.title, s.cover_url, s.audiourl,
        s.duration_seconds, s.is_explicit, s.play_count, s.created_at,
        a.name       AS artist_name,
        a.id         AS artist_id,
        al.title     AS album_title,
        al.id        AS album_id,
        g.name       AS genre
      FROM songs s
      LEFT JOIN artists a  ON s.artist_id = a.id
      LEFT JOIN albums  al ON s.album_id  = al.id
      LEFT JOIN genres  g  ON s.genre_id  = g.id
      ORDER BY s.title ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error("getAllSongs error:", error);
    res.status(500).json({ error: "Failed to fetch songs" });
  }
};

// ─── GET song by id ───────────────────────────────────────────────────────────
exports.getSongById = async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(`
      SELECT
        s.id, s.title, s.cover_url, s.audiourl,
        s.duration_seconds, s.is_explicit, s.play_count, s.created_at,
        a.name       AS artist_name,
        a.id         AS artist_id,
        a.image_url  AS artist_image,
        al.title     AS album_title,
        al.id        AS album_id,
        g.name       AS genre
      FROM songs s
      LEFT JOIN artists a  ON s.artist_id = a.id
      LEFT JOIN albums  al ON s.album_id  = al.id
      LEFT JOIN genres  g  ON s.genre_id  = g.id
      WHERE s.id = $1
    `, [id]);

    if (rows.length === 0) return res.status(404).json({ error: "Song not found" });
    res.json(rows[0]);
  } catch (error) {
    console.error("getSongById error:", error);
    res.status(500).json({ error: "Failed to fetch song" });
  }
};

// ─── Record a Play (called by frontend when track actually starts) ─────────────
exports.recordPlay = async (req, res) => {
  try {
    const { id } = req.params;
    const email = req.user?.email; // from authMiddleware

    // Increment play_count (silently skip if song not found)
    await pool.query(
      'UPDATE songs SET play_count = COALESCE(play_count, 0) + 1 WHERE id = $1',
      [id]
    ).catch(() => {});

    // Save to play_history (silently skip if table missing or constraint fails)
    if (email) {
      await pool.query(
        `INSERT INTO play_history (user_email, song_id) VALUES ($1, $2)`,
        [email, id]
      ).catch(() => {});
    }

    res.json({ ok: true });
  } catch (error) {
    // Don't fail — play tracking should never break the app
    res.json({ ok: false });
  }
};

// ─── Stream audio with HTTP range support ─────────────────────────────────────
exports.streamAudio = async (req, res) => {
  try {
    const { id } = req.params;

    const { rows } = await pool.query(
      "SELECT audiourl FROM songs WHERE id = $1",
      [id]
    );

    if (!rows.length || !rows[0].audiourl)
      return res.status(404).json({ error: "Audio not found" });

    let audioUrl = rows[0].audiourl;

    const driveId = extractDriveId(audioUrl);
    if (driveId) audioUrl = await resolveDriveUrl(driveId);

    // HEAD to get file size
    let totalSize = null;
    try {
      const head = await axios.head(audioUrl, {
        headers: { "User-Agent": "Mozilla/5.0" },
        maxRedirects: 5,
        validateStatus: () => true,
      });
      totalSize = parseInt(head.headers["content-length"], 10) || null;
    } catch {}

    const rangeHeader = req.headers["range"];

    if (!rangeHeader || !totalSize) {
      const response = await axios({
        method: "GET",
        url: audioUrl,
        responseType: "stream",
        headers: { "User-Agent": "Mozilla/5.0" },
        maxRedirects: 5,
      });
      res.set({
        "Content-Type": "audio/mpeg",
        "Accept-Ranges": "bytes",
        ...(totalSize && { "Content-Length": totalSize }),
        "Cache-Control": "public, max-age=3600",
      });
      return response.data.pipe(res);
    }

    const [startStr, endStr] = rangeHeader.replace("bytes=", "").split("-");
    const chunkStart = Math.max(0, parseInt(startStr, 10));
    const chunkEnd   = endStr ? Math.min(parseInt(endStr, 10), totalSize - 1) : totalSize - 1;
    const chunkSize  = chunkEnd - chunkStart + 1;

    if (chunkStart > chunkEnd)
      return res.status(416).set("Content-Range", `bytes */${totalSize}`).end();

    const response = await axios({
      method: "GET",
      url: audioUrl,
      responseType: "stream",
      headers: {
        "User-Agent": "Mozilla/5.0",
        "Range": `bytes=${chunkStart}-${chunkEnd}`,
      },
      maxRedirects: 5,
    });

    res.status(206).set({
      "Content-Type": "audio/mpeg",
      "Content-Range": `bytes ${chunkStart}-${chunkEnd}/${totalSize}`,
      "Content-Length": chunkSize,
      "Accept-Ranges": "bytes",
      "Cache-Control": "public, max-age=3600",
    });

    response.data.pipe(res);

  } catch (error) {
    if (!res.headersSent) {
      console.error("streamAudio error:", error.message);
      res.status(500).json({ error: "Failed to stream audio" });
    }
  }
};
